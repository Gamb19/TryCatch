/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package co.edu.udes.tryandcatch;

/**
 *
 * @author molin
 */
public class TryAndCatch {

    public static void main(String[] args) {
        
    }
}
